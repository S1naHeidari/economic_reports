#include <stdio.h>
#include <stdlib.h>

#define MAX_STR 32

int main()
{
  FILE *infile;  
  char  name[MAX_STR];
  char  major[MAX_STR];
  float gpa;

  infile = fopen("students.txt", "r");
  if (!infile) {
    printf("Error: could not open file\n");
    exit(1);
  }
  
  while (1) {
    fscanf(infile, "%s %s %f", name, major, &gpa);
    if (feof(infile))
      break;
    printf("Student: %10s, Major: %15s, GPA: %4.1f\n", name, major, gpa);
  }

  fclose(infile);
}
