#include <stdio.h>
#include <unistd.h>

int main()
{
  int i;

  for (i=1; i<=5; i++) {
    printf("%d ", i);
    fflush(stdout);
    sleep(1);
  }

  printf("\n");
}
