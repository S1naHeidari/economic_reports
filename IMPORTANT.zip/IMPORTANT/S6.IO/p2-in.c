#include <stdio.h>
#include <stdlib.h>

int main()
{
  FILE *infile;
  char text[80];
  int count, numBytes;

  infile = fopen("dragons.txt", "r");
  if (!infile) {
    printf("Error: could not open file\n");
    exit(1);
  }

// Reading in formatted input

  fscanf(infile, "%d %s", &count, text);
  printf("Using fscanf, we read: %d %s\n", count, text);
  fclose(infile);

  infile = fopen("dragons.txt", "r");
  if (!infile) {
    printf("Error: could not open file\n");
    exit(1);
  }
  
// Reading in unformatted input

  numBytes = fread(text, 1, 80, infile);
  text[numBytes] = '\0';
  fclose(infile);

  printf("Using fread, we read: %s\n", text);

}
